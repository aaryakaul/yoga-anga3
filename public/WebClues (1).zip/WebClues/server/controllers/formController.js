const { validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');

const Form = require('../models/Form');
const formController = async (req, res, next) => {
  console.log(req.file);

  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  const { name, email, password } = req.body;
  const file = req.file;

  try {
    let form = await Form.findOne({ email });
    if (form) {
      return res.status(400).json({ msg: 'User already exists' });
    } else {
      form = new Form({
        name,
        email,
        password,
        fileName: file.originalname,
        filePath: file.path,
        fileType: file.mimetype,
        fileSize: fileSizeFormatter(file.size, 2), // 0.00 upto 2 decimal
      });

      const salt = await bcrypt.genSalt(10);

      form.password = await bcrypt.hash(password, salt);

      await form.save();

      res.status(201).send('Form Uploaded successfully');
    }
  } catch (error) {
    res.status(400).send(error.message);
  }
};

const fileSizeFormatter = (bytes, decimal) => {
  if (bytes === 0) {
    return '0 Bytes';
  }
  const dm = decimal || 2;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'YB', 'ZB'];
  const index = Math.floor(Math.log(bytes) / Math.log(1000));
  return (
    parseFloat((bytes / Math.pow(1000, index)).toFixed(dm)) + ' ' + sizes[index]
  );
};

module.exports = {
  formController,
};
