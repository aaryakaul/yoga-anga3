import React, { useState } from 'react';
import axios from 'axios';

function Form() {
  const [userData, setUserData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const [selectedFile, setSelectedFile] = useState(null);

  const onImageChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      setSelectedFile(event.target.files[0]);
    }
  };

  const fileUploadHandler = () => {
    const data = new FormData();
    data.append('name', userData.name);
    data.append('email', userData.email);
    data.append('password', userData.password);
    data.append('image', selectedFile);
    axios
      .post('http://localhost:5000/api/form', data, {
        headers: {
          'Content-Type': 'application/json',
        },
      })
      .then((res) => {
        console.log(res);
      });
  };
  return (
    <div>
      <div className='login-page'>
        <div className='form'>
          <div className='login'>
            <div className='login-header'>
              <h3>LOGIN</h3>
              <p>Please enter your credentials to login.</p>
            </div>
          </div>
          <form className='login-form'>
            <input
              type='text'
              placeholder='name'
              onChange={(e) =>
                setUserData({ ...userData, name: e.target.value })
              }
            />
            <input
              type='email'
              placeholder='email'
              onChange={(e) =>
                setUserData({ ...userData, email: e.target.value })
              }
            />
            <input
              type='password'
              placeholder='password'
              onChange={(e) =>
                setUserData({ ...userData, password: e.target.value })
              }
            />
            <input type='file' onChange={onImageChange} />
            <button onClick={fileUploadHandler}>Upload</button>
            <p className='message'>Web Clues Test</p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Form;
