import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './userlist.css';

const UserList = () => {
  const [data, setData] = useState([]);
  useEffect(() => {
    const getData = async () => {
      const { data } = await axios.get('http://localhost:5000/api/form');
      setData(data);
      console.log(data);
    };
    getData();
  }, []);

  return (
    <div className='row' style={{ marginRight: '5%', marginLeft: '5%' }}>
      {data.map((res) => {
        return (
          <div
            className='col-names'
            key={res._id}
            style={{ textAlign: 'center' }}
          >
            <img
              src={res.profileImage}
              width={100}
              height={100}
              alt={res.name}
            />
            <h3>{res.name}</h3>
            <p>{res.email}</p>
          </div>
        );
      })}
    </div>
  );
};

export default UserList;
